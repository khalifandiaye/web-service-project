#!/bin/bash
echo `curl -s -H "Content-Type: application/atom+xml;type=entry" -d "<?xml version="1.0"encoding="utf-8">
<entry>
<id>kjadfjfl</id>
<link rel='8' href='xx'/>
<content>First comment</content>
</entry>" "http://127.0.0.1:3000/" -D h`
