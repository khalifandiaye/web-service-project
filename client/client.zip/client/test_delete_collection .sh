#!/bin/bash
echo `curl --request DELETE "http://127.0.0.1:3000/2"`
